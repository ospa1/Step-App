package com.example.stepapp

class StatsTest extends GroovyTestCase {
}
